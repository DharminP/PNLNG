export class cart {
    cid?: number;
    cpid?: number;
    cpname?: string;
}